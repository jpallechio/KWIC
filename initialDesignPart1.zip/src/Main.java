import java.util.ArrayList;

public class Main {
    private ArrayList<Line> lines;
    public static void main(String[] args) {
        //call readFile
        //call
    }
    private void sortLines(Line[] lines){}
    public void shitAllLines(Line[] lines){}
    public void readFile(String filename){}
    private void printLines(){}
}

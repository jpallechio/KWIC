import java.util.LinkedList;

public class Line {
    LinkedList<String> line = new LinkedList<>();

    public void addWord(String string){}
    public void shiftLine(){}
    public int compareTo(){ return 0;}
}
